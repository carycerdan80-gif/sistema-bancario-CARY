package ar.com.centro8.java.curso.sistemabancario.entidades.cuentas;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.ToString;

@Getter 
@ToString 
@AllArgsConstructor 
public class Cheque {
    private float montoCheque;
    private String bancoEmisor;
    private LocalDate fechaPago;

}
