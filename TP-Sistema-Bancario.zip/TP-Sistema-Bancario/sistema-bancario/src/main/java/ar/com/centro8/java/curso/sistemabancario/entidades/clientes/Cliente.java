package ar.com.centro8.java.curso.sistemabancario.entidades.clientes;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Getter 
@ToString 
@RequiredArgsConstructor 
public abstract class Cliente {
    private final int numeroCliente;
}
