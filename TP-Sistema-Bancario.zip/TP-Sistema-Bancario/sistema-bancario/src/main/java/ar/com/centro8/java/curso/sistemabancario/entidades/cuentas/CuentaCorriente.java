package ar.com.centro8.java.curso.sistemabancario.entidades.cuentas;

import ar.com.centro8.java.curso.sistemabancario.entidades.clientes.Cliente;
import lombok.Getter;
import lombok.ToString;

@Getter 
@ToString (callSuper = true)
public class CuentaCorriente extends Cuenta {
    private float montoDescubierto;
     // constructor
    public CuentaCorriente(int numeroCuenta, Cliente cliente, float montoDescubierto) {
        super(numeroCuenta, cliente);
        this.montoDescubierto = montoDescubierto;
    }

    // implemetacion del método heredado
    @Override
    public void extraerEfectivo(float monto){
        if (monto<=0 ) {
            return ;      
        }
        
        float dineroDisponible = saldo + montoDescubierto;
        if (monto <= dineroDisponible) {
            saldo -= monto;
        }
    }

    // relación de uso
    public void depositarCheque(Cheque cheque){
        if (cheque == null) {
            return;   
        }
        if(cheque.getMontoCheque() > 0){
            saldo += cheque.getMontoCheque();
        }
        
    }

}
