package ar.com.centro8.java.curso.sistemabancario.entidades.cuentas;

import ar.com.centro8.java.curso.sistemabancario.entidades.clientes.Cliente;
import lombok.Getter;
import lombok.ToString;

@Getter 
@ToString (callSuper = true)
public class CajaAhorro extends Cuenta {
    private float tasaInteres;

    //Constructor 
    public CajaAhorro(int numeroCuenta, Cliente cliente, float tasaInteres) {
        super(numeroCuenta, cliente);
        this.tasaInteres = tasaInteres;
    }
    
    //Método heredado
    @Override
    public void extraerEfectivo(float monto) {
        if (monto <= 0) {
            return;
        } 
        if (monto > saldo) {
            return;   
        }
        saldo -=monto;
    }
     //Método propio
    public void cobrarInteres(){
        float interes = saldo * tasaInteres /100;
        saldo= saldo + interes;
    }

}
