package ar.com.centro8.java.curso.sistemabancario.entidades.cuentas;

import ar.com.centro8.java.curso.sistemabancario.entidades.clientes.ClienteEmpresa;
import lombok.Getter;
import lombok.ToString;

@Getter 
@ToString (callSuper = true)
public class CuentaConvertibilidad extends CuentaCorriente {
    private float saldoDolares;

    //Constructor
    public CuentaConvertibilidad(int numeroCuenta, ClienteEmpresa cliente, float montoDescubierto) {
        super(numeroCuenta, cliente, montoDescubierto);
    }

    // método depositar Dolares
    public void depositarDolares(float monto){
        if (monto > 0) {
            saldoDolares +=monto;   
        }
    }
       //Método extraer Dolares
    public  void extraerDolares(float monto){
        if (monto <=0) {
            return; 
        }
        if (monto <=saldoDolares) {
            saldoDolares -=monto;
        }
    }

     //método convertir Pesos a dolares
     public void convertirPesosADolares(float montoPesos,float tasaConversion ){
        if (montoPesos <=0) {
            return ;   
        }
        if (tasaConversion <=0) {
            return ;   
        }
        if (montoPesos > saldo) {
            return ;  
        }
        float dolaresRecibidos= montoPesos/tasaConversion;
        saldo -=montoPesos;
        saldoDolares +=dolaresRecibidos;
     }

     //Método convertir Dolares a pesos
     public void convertirDolaresAPesos(float montoDolares, float tasaConversion){
        if (montoDolares <=0) {
            return ;   
        }
        if (tasaConversion <=0) {
            return ;  
        }
        if (montoDolares >saldoDolares) {
            return ; 
        }
        float pesosRecibidos= montoDolares *tasaConversion;
        saldoDolares -=montoDolares;
        saldo += pesosRecibidos;
     }


}
