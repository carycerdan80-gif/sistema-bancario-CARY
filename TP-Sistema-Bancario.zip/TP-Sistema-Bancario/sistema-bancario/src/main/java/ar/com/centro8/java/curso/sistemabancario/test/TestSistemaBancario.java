package ar.com.centro8.java.curso.sistemabancario.test;

import java.time.LocalDate;
import ar.com.centro8.java.curso.sistemabancario.entidades.clientes.ClienteEmpresa;
import ar.com.centro8.java.curso.sistemabancario.entidades.clientes.ClienteIndividual;
import ar.com.centro8.java.curso.sistemabancario.entidades.cuentas.CajaAhorro;
import ar.com.centro8.java.curso.sistemabancario.entidades.cuentas.Cheque;
import ar.com.centro8.java.curso.sistemabancario.entidades.cuentas.CuentaConvertibilidad;
import ar.com.centro8.java.curso.sistemabancario.entidades.cuentas.CuentaCorriente;


public class TestSistemaBancario {
    public static void main(String[] args) {

        System.out.println(" ======= CLIENTE Nº1 ========");
        ClienteIndividual cliente1 = new ClienteIndividual(1, "Hyun","Bin", "12345678");
        System.out.println("Número de cliente: " + cliente1.getNumeroCliente());
        System.out.println("Nombre : " + cliente1.getNombre());
        System.out.println("Apellido: " + cliente1.getApellido());
        System.out.println("Dni: " + cliente1.getDni());

        System.out.println("\n======== CAJA DE AHORRO =======");
        CajaAhorro cuenta1 = new CajaAhorro(1, cliente1, 2.5f);
        System.out.println("Número de cuenta: " + cuenta1.getNumeroCuenta());
        System.out.println("Titular de la cuenta cliente Nº :" + cliente1.getNumeroCliente());
        System.out.println("Tasa interés mensual: " + cuenta1.getTasaInteres() + "%");
        System.out.println("Saldo inicial : $ " + cuenta1.getSaldo());

        System.out.println("\n-------- DEPÓSITO  --------");
        cuenta1.depositarEfectivo(-2000f);
        cuenta1.depositarEfectivo(50000f);
        System.out.println("Monto depositado: $ 50000");
        System.out.println("Saldo actual: $ " + cuenta1.getSaldo());

        System.out.println("\n-------- EXTRACCIÓN--------");
        cuenta1.extraerEfectivo(20000f);
        System.out.println("Monto extraído :$ 20000");
        System.out.println("Saldo actual: $ " + cuenta1.getSaldo());

        System.out.println("\n------INTERES MENSUAL--------");
        float interes = cuenta1.getSaldo()* cuenta1.getTasaInteres()/100;
        System.out.println("Interes cobrado : $ " + interes);
        cuenta1.cobrarInteres();
        System.out.println("Saldo mas interes: $ " + cuenta1.getSaldo());

        // -------------------------------------------------------------------
        System.out.println("\n========CLIENTE Nº 2========");
        ClienteIndividual cliente2 = new ClienteIndividual(2, "Ji", "Sung", "98765432");
        System.out.println("Número de cliente : " + cliente2.getNumeroCliente());
        System.out.println("Nombre :" + cliente2.getNombre());
        System.out.println("Apellido: " + cliente2.getApellido());
        System.out.println("Dni :" + cliente2.getDni());

        System.out.println("\n======== CUENTA CORRIENTE========");
        CuentaCorriente cuenta2 = new CuentaCorriente(2, cliente2, 25000f);
        System.out.println("Número de cuenta : " + cuenta2.getNumeroCuenta());
        System.out.println("Titular de la cuenta cliente Nº :" + cliente2.getNumeroCliente());
        System.out.println("Monto al Descubierto :" + cuenta2.getMontoDescubierto());

        System.out.println("\n-------- DEPOSITO EN CHEQUE--------");
        Cheque cheque1= new Cheque(50000f, "Banco Provincia", LocalDate.of(2026, 10, 01));
        System.out.println("Banco Emisor :" + cheque1.getBancoEmisor());
        System.out.println("Fecha de Pago del cheque:" + cheque1.getFechaPago());
        cuenta2.depositarCheque(cheque1);
        System.out.println("Monto del cheque :" + cheque1.getMontoCheque());

        System.out.println("\n--------DEPOSITO EN EFECTIVO---------");
        cuenta2.depositarEfectivo(100000f);
        System.out.println("Deposito efectivo :" + 100000f);

        System.out.println("\n---------TOTAL DEPOSITOS---------");
        System.out.println("Total efectivo + cheque:"  + cuenta2.getSaldo());

        System.out.println("\n--------EXTRACCIÓN--------");
        cuenta2.extraerEfectivo(160000f);
        System.out.println("Monto extraído:" + 160000f);
        System.out.println("Saldo actual:" + cuenta2.getSaldo());

        System.out.println("\n------ INTENTO DE SUPERAR EL DESCUBIERTO--------");
        cuenta2.extraerEfectivo(30000f);
        System.out.println("Monto al descubierto: "+ cuenta2.getMontoDescubierto());
        System.out.println("Saldo actual: " + cuenta2.getSaldo());
        System.out.println("Intento de extracción:" + 30000f);
        System.out.println("Operación rechazada su saldo despúes del intento es:" + cuenta2.getSaldo());
        
        //------------------------------------------------------------------------------------------
        System.out.println("\n ======== CLIENTE Nº 3 ========");
        ClienteEmpresa cliente3 = new ClienteEmpresa(3, "Logistica Cary", "27275805817");
        System.out.println("Número de cliente : " + cliente3.getNumeroCliente());
        System.out.println("Nombre de Fantasía : " + cliente3.getNombreFantasia());
        System.out.println("CUIT : " + cliente3.getCuit());

        System.out.println("\n======== CUENTA CONVERTIBILIDAD ========");
        CuentaConvertibilidad cuenta3 = new CuentaConvertibilidad(3, cliente3, 25000f);
        System.out.println("Número de cuenta :" +cuenta3.getNumeroCuenta());
        System.out.println("Titular de la Cuenta cliente Nº :" + cliente3.getNumeroCliente());
        System.out.println("Monto al descubierto:" + cuenta3.getMontoDescubierto());
        System.out.println("Saldo inicial en dolares: U$$ " +cuenta3.getSaldoDolares());
        
        System.out.println("\n-------- DEPOSITO EFECTIVO--------");
        cuenta3.depositarEfectivo(130000f);
        System.out.println("Deposito en Pesos :$ " + cuenta3.getSaldo());

        System.out.println("\n-------- DEPOSITO EN CHEQUE--------");
        Cheque cheque2= new Cheque(80000f, "Banco Nación", LocalDate.of(2026, 9, 28));
        System.out.println("Banco Emisor :" + cheque2.getBancoEmisor());
        System.out.println("Fecha de Pago del cheque:" + cheque2.getFechaPago());
        cuenta3.depositarCheque(cheque2);
        System.out.println("Monto del cheque :" + cheque2.getMontoCheque());

        System.out.println("\n---------TOTAL DEPOSITOS---------");
        System.out.println("Total de deposito en efectivo mas cheque: $" + cuenta3.getSaldo());

        System.out.println("\n---------EXTRACCIÓN EN PESOS--------");
        cuenta3.extraerEfectivo(50000f);
        System.out.println("Pesos extraidos:$ "+ 50000f);
        System.out.println("Saldo actual en cuenta : $ " + cuenta3.getSaldo());

        System.out.println("\n-------- DEPOSITO  EN DOLARES --------");
        cuenta3.depositarDolares(1000f);
        System.out.println("Monto de deposito en : U$$ " + cuenta3.getSaldoDolares());

        System.out.println("\n-------- EXTRACCIÓN DE DOLARES---------");
        float saldoAntesExtraccion= cuenta3.getSaldoDolares();
        float montoSolicitado = 500f;
        cuenta3.extraerDolares(montoSolicitado);
        float montoExtraido = saldoAntesExtraccion - cuenta3.getSaldoDolares();
        System.out.println("Monto Solicitado en : U$$ " + montoSolicitado);
        System.out.println("Monto Extraído en :U$$" + montoExtraido);
        System.out.println("Saldo actual en:U$$" + cuenta3.getSaldoDolares());


        System.out.println("\n--------SALDOS EN CUENTA --------");
        System.out.println("Saldo en pesos: $ " + cuenta3.getSaldo());
        System.out.println("Saldo en dolares: U$$ " + cuenta3.getSaldoDolares());

        System.out.println("\n-------- CONVERSION DOLAR A PESOS--------");
        float saldoEnCuentaPesos =cuenta3.getSaldo();
        cuenta3.convertirDolaresAPesos(300, 1500);
        float pesosRecibidos = cuenta3.getSaldo()-saldoEnCuentaPesos;
        System.out.println("Monto Recibido por 300 dolares: $ " + pesosRecibidos);
        System.out.println("Saldo Actual en : U$$" + cuenta3.getSaldoDolares());

        System.out.println("\n--------CONVERSION PESOS A DOLARES------");
        System.out.println("Saldo en pesos + Monto recibido por 300 dolares : $" + cuenta3.getSaldo());
        float saldoEnCuentaDolares = cuenta3.getSaldoDolares();
        cuenta3.convertirPesosADolares(150000, 1450);
        float dolaresRecibidos = cuenta3.getSaldoDolares() - saldoEnCuentaDolares;
        System.out.println("Monto Recibido por 150000 pesos : U$$ " + dolaresRecibidos);
        System.out.println("Saldo actual en : $ " + cuenta3.getSaldo());
        
        System.out.println("\n -------- SALDOS FINALES--------");
        System.out.println(" Saldo en Pesos : $" + cuenta3.getSaldo());
        System.out.println("Saldo en Dolares : U$$ " + cuenta3.getSaldoDolares());

        System.out.println("-------------------------------------------------------------");

    }

}
