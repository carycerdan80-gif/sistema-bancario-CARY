# DESCRIPCIONES
PRIMERA ACTIVIDAD ENTREGABLE OBLIGATORIA DE PROGRAMACION ORIENTADA A OBJETOS
  ***RELACIONES ENTRE CLASES***
  Modelar un sistema bancario que permita registrar diferentes tipos de clientes y cuentas de un Banco.

  # Utilizo
  JAVA,VISUAL ESTUDIO CODE,MAVEN,SPRING BOOT,LOMBOK, GITHUB,DRAW.IO.NET PARA EL DIAGRAMA UML

  # DIAGRAMA UML
  Antes  de empezar cree un diagrama UML en la página draw.io.net,para representar:
  .las clases
  .los atributos
  .los métodos
  .las relaciones entre clases
  .las herencias
  .las clases abstractas

  # Carpeta
  Creo una carpeta llamada TP Sistema Bancario para guardar el proyecto

  # Paquetes
  luego ingreso a VISUAL para crear los paquetes(Clic derecho New Java Package)
  .sistemabancario
  .entidades
  .clientes
  .cuentas
  
  # Clases
  Dentro del paquete clientes creo las clases(Clic derecho New Java File(class) )
  .Clase Cliente 
  .Clase ClienteIndividual
  .Clase ClienteEmpresa

  Dentro del paquete cuentas creo las clases(Clic derecho New Java File(class) )
  .Clase Cuenta
  .Clase CajaAhorro
  .Clase CuentaCorriente
  .Clase Cheque
  .Clase CuentaConvertibilidad

  ## Implementación de las clases
  # Clase Cliente: es una super clase abstracta de clinteIndividual y ClienteEmpresa
  .Reúne el numeroCliente  como atributo común a ambos tipos de clientes
  .representa un cliente general,no se puede instanciar directamente
  .numeroCliente es private se consulta mediante  get.numeroCliente()
  . numeroCliente es final por lo que se asigna al contruir un objeto y no se puede reasignar
  . las clases hijas extienden de Cliente e inicializan el numero mediante super(numeroCliente)
  .@Getter:para consultar el número del cliente.get(numeroCliente)
  .@RequeridArgsConstructor:genera el constructor que recibe numeroCliente,desde CuentaIndividual lo llamo  con super(numeroCliente)
  .@ToString:genera representacion en texto del objeto.toString()
  .NO utilizo un Setter porque numeroCliente es final y no debe cambiar despues de crear el objeto.

  # Clase ClienteIndividual:
  .es una clase que representa a una persona cliente del banco.
  .Hereda de Cliente  el atributo numeroCliente y agrega los propios nombre ,apellido,dni
  .*Herencia* extends Cliente  establece que ClienteIndividual es un tipo de cliente
  .*Encapsulamiento* sus atributos son privados Lombox genera Getter 
  .@Getter: para consultar los aributos nombre,apellido,dni propios y numero cliente heredado
  .@Setter:para modificar los datos de los clientes nombre,apelldio,dni, pero no numerocliente porque es final.
  .@ToString(callSuper=true): para mostrar tanto los atributos propios y los heredados
  .El Constructor: Recibe el numeroCliente y los datos propios.Super(numeroCliente) llama al constructor de la clase padre
  .this asigna los valores de los atributos de esta clase , this.nombre.this.apellido.this.dni


 # Clase ClienteEmpresa: 
 .Es una clase hija de la clase Cliente
 .Representa a los clientes empresariales del banco.
 .Se encuentra dentro del paquete de clientes
 .Herencia:mediante extends Cliente,recibe el atributo numeroCliente deefinido en la clase padre
 .Agrega atributos propios :nombreFantasia,cuit 
 .nombreFantasia:guarda  el nombre comercial de la empresa
 .cuit: guarda su numero de identificacion tributaria
 .Son de tipo String porque representan cadenas de texto (cuit es un identificador no hace calculos)
 .Uso anotaciones lombox 
 .@Getter:para consultar  nombreFntasia y cuit, mediante  metodos getNombreFantasia() y getCuit(), el getNumeroCliente lo hereda
 .@Setter : genera el metodo para modificar esos atributos en caso que cambie el nombre del cliente empresa
 .@ToString: permite que el metodo toString() incluya los atributos propios
 .(callSuper=true):llama al  metodo toSring() de la clase padre.
 .Constructor: con parámetros recibe( el numeroCliente,nombreFantasia,CUIT)
 .la instruccion super(numeroCliente) llama al constructor Cliente para asignar el numero
 .despues this.nombreFantasia= nombreFantasia y this.cuit=cuit asignan valores recibidos  a los atributos del objeto.

 ## Clases Cuenta:
 .Es una clase padre de todas las cuentas bancarias.
 .se encuentra en el paquete entidades.cuenta.
 .Tiene caracteristicas y operaciones comunes de las cuentas.
 .La declaré abstracta  porque no se crean objetos directamente de Cuenta.
 .se sino de sus clases hijas como cajaAhorro y cuentaCorriente.
 .cuentaConvertibilidad tambien es un tipo de cuenta porque hereda de cuenta corriente.
 .Tiene atributos:
 .numeroCuenta:identifica  la cuenta
 .cliente:representa al cliente asociado.
 .saldo:guarda el dinero de la cuenta  en pesos.
 .Declaré a numeroCuenta y cliente como private y final: solo se asignan al crear cuenta y luego no se pueden reemplazar
 .Declare saldo como protected para que sus clases hijas puedan usarlo directamente en sus operaciones.
 .@Getter:genera los metodos getNumeroCuenta(),get.Cliente(),get.Saldo()
 .@ToString:genera un metodo toString() que muestra datos de la cuenta como texto
 .@RequiredArgsConstructor:genera un constructor  con los atributos final numeroCuenta y cliente.
 .Saldo no entra en este constructor porque no es final.
 . depositarEfectivo(float monto):recibe el monto que se quiere depositar
 .if(monto<=0)primero verifico que el saldo sea mayor o igual a cero.
 .saldo+=monto; si es correcto sumo al saldo
 .else( ): si no es informo que el deposito no se realizo
 .extraerEfectivo(float monto) es abstracto porque cada tipo de cuenta tiene reglas distintas 
 .Las clases hijas implementan este metodo con@Override
 . En esta clase se aplican abtraccion, encapsulamiento, relacion entre clases , herencia y polimorfismo.

 ## Clase Caja Ahorro
 . Es una clas hija  de cuenta y se encuentra en el paquete de endidades.cuentas
 .Representa una caja de ahorro que permite :
 . Depositar efectivo , el que desee el cliente
 .Extraer Efectivo, sin exedeer el saldo.
 . cobrar interes , interes mensual
 .hereda de cuenta el numeroCuenta,cliente asociado,el saldo y el metodo depositar efectivo
 .agrega el atributo propio tasaInteres de tipo float que representa el porcentaje aplicado a la cuenta.
 .@Getter  genera  get.Tasainteres() para consultar la tasa.
 .los metodos para consultar los atributos heredados ya estan definidos @Getter cuenta
 @ToString (callSuper=true)permite mostrar la tasa de interes junto con los datos que muestra toString()cuenta
 .Contructor : recibe numeroCuenta, Cliente,tasaInteres , con super( numeroCuenta,Cliente) llama al constructor de cuenta para signar un numero y el cliente. con this.tasaInteres=tasaInteres;asigna la tasa al atributo propio
 con@Override implementa extraerEfectivo(float monto)que esta declarado como abstracto en cuenta
 .extraerEfectivo(float monto):recibe en monto la cantidad que se quiere extraer.
 ."recordar void significa que no devuelve un resultado" ,
 .si el monto que quiero extraer es  menor o igual a cero termino el metodo con retur sin modificar saldo
 .if(monto <= 0):si el monto es menor o igual a cero 
 .retur;: termina la ejecucion si no se cumple
 . if(monto > saldo):si el monto supera el saldo termino el metodo
  .con return porque la caja de ahorro no permite descubierto
 .saldo-= monto; si no lo supera resto el monto del saldo
 .creo una variable  local llamada interes y calculo el porcentaje sobre el saldo actual despues sumo ese interes al saldo de caja de ahorro
 .float interes = saldo *tasaInteres/100;
  saldo = saldo + ineteres;
  la division /100 convierte la tasa expresada como porcentaje 2,5%

 ## Clase Cuente Corriente
 . Es una clase  hija de Clase cuenta.
 .representa una cuenta que permite realizar depositos en efectivo y en cheque ,extraer dinero hasta un limite descuebierto
 . Hereda de cuenta el NumeroCuenta,cliente asociado,el saldo y el metodo depositarEfectivo
 .agrega el atributo montoDescubierto,que indica cuanto dinero puede retirar el cliente por encima de  su saldo.
 .@Getter:genera el metodo get.MontoDescubierto()para consultar ese atributo.los demas metodos los hereda decuenta
 .@ToString(callSuper=true);permite que el texto incluya montoDescubierto
 . con super(numeroCuenta,cliente)inicializa los atributos de cuenta
 .this.montoDescubierto=montoDecubierto; inicializa el atributo propio
 .con@Override implementa extraerEfectivo(float monto)que esta declarado como abstracto en cuenta
 .extraerEfectivo(float monto):recibe en monto la cantidad que se quiere extraer.
 .si el monto que quiero extraer es  menor o igual a cero termino el metodo con return y no hago la extraccion
 .if(monto <= 0):si el monto es menor o igual a cero 
 .retur;: termina la ejecucion si no se cumple
 .como el metodo es void, return no devuelve dinero ni un valor simplemente deja de ejecutar las instruccionesque siguen
 .float dineroDisponible = saldo + montoDescubierto: 
 .creo una variable llamada dineroDisponible y guardo en ella la suma del saldo mas monto descuebierto autorizado
 .dineroDisponible es una variable local existe mientras se ejecuta extraerEfectivo
 if(monto<= dineroDisponible): compruebo si el monto es menor o igual al dinero disponible
 si se cumple la condicion , ejecuta saldo -= monto; y se realiza la extraccion , si el monto es mayor no se descuenta nada.
 .declaro un metodo llamado depositarCheque recibe como parametro un objeto del tipo Cheque al que lo llamo cheque.void significa que no devulve valor.
 .if(cheque == null) si que es  igual null ,si no recibi un objeto cheque salgo del metodo
  con return y no hago el deposito
  == compara si la referencia e sigual a null, null significa que no apuenta a ningun objeto
  if (cheque.getMontoCheque() > 0):consulto el monto del cheque  si es mayor a cero
  saldo += cheque.getMontoCheque(): sumo ese monto al saldo de cuenta corriente. si es cero o negativo el monto no cambia. 
  ## CALSE CHEQUE 
  .Se encuentra en el paquete de entidades.cuentas
  .Representa los datos de un cheque.Cuenta corriente utiliza un objeto deesta clase para consultar su monto y realizar un deposito
  .NO hereda de Cuenta: cuentaCorriente lo recibe como parametro en depostarCheque(Cheque cheque)para consultar monto.
  .Tiene tres atributos
  montoCheque:de tipo float guarda el importe del cheque
  bancoEmisor:de tipo String guarda el nombre del banco que lo emitio
  fecha de pago  del tipo LocalDate guarda la fecha de pago sin incluir la hora
  .Los atributos  son private por lo que se consultan desde afura de la clasemediante metodos
  .@Getter:genera esos metodos de consulta getMontoCheque() es el que usa cuentaCorriente para obtener el importe
  .@ToString:genera un metodo que muestra los datos del cheque como texto
  @AllArgsConstructor: genera un constructor que recibe los tres atributos en orden (monto,bancoEmisor,fechaPago)
  OBS: cree cheque como clase para reunir los datos de un cheque. cuando llamo a depositarCheque le paso un objeto
  llamado ccheque a la cuenta corriente la cuenta consulta su monto  por medio del metodo get.MontoCheque() y si es positivo lo suma al saldo

  ## Clase Convertibilidad
  .Es una clase hija de cuenta corriente y se encuentra en el paquete entidades.cuentas.
  .Representa una cuenta para clientes empresa que puede operar en pesos y dolares
  .Este tipo de cuenta permitirá
   realizar todo lo que hacía una cuenta corriente y además permitirá:
  .Depositar dólares.
  . Extraer dólares. (Para los dólares no se acepta el giro en descubierto)
  . Convertir pesos a dólares. (La tasa d

 conversión será un parámetro)
  .Convertir dólares a pesos. (La tasa de conversión será un parámetro)
  .Al heredar de cuenta corriente puede depositar efectivo en pesos,depositar cheque y extraer efectivo en pesos
  .con el descubierto autorizado tambien conserva el numero de cuenta, el cliente asociado y el saldo en pesos que proviene de cuenta.
  .agrega el atributo saldoDolres de tipo float,para guardar los dolares disponibles
  el atributo heredado de cuenta  saldo representa los pesos.
  @Getter: genera getSaldoDolares()para consultar los dolares, los getter heredados ya vienen de la clase padre cuenta
  .@ToString(callSuper=true)permite mostrar saldoDolres junto con los datos que muestran los toString() de cuenta corriente y cuenta.
  .el constructor recibe numeroCuenta,cliente empresa y montoDescubierto, con super(numeroCuenta,cliente,MontoDescubierto) llama al constructo de cuenta corriente.
  .creo un metodo llamado depositarDolares(float monto):recibe el monto que quiero depositar,
  .depositarDolares(float monto) suma el monto a saldoDolares únicamente si es mayor que cero.
  .if(monto > 0): lo leo asi, si el monto es mayor a cero .
  saldoDolares += monto; si se cumple la condicion  sumo el monto al saldo dolares.
  si es cero o negativo el metodo termina sin modificar el saldo
  . creo un metodo extraerDolares:
  .extraerDolares(float monto) comprueba que el monto sea positivo y que no supere saldoDolares.
  if (monto <= 0) si el monto es menor o igual a cero,si ocurre return detiene el metodo
  if(nonto <= saldoDolares) si el monto solicitado es menor o igual al saldo solicitado compruebo que tenga dolares.
   Si se cumplen ambas condiciones, lo resta. No permite descubierto en dólares.
  .saldoDolares-= monto; al saldo dolares le resto el monto solicitado y guardo el resultado como nuevo saldo dolares.
  .creo unmetodo convertirDolaresAPesos:
  .recibe dos  datos ( float montoDolares,float tasaConversion)
  .montoDolares  es lo que quiero convertir
  .tasaConversion  cuantos pesos vale un dolar.
  .if(monto <=o) si la cantidad d e dolares  en menor o igual a cero termino el metodo con retur
  .if(tasaConvercion <=0) si la tasa de conversion es menor o igual a cero termino el metodo con  return 
  .if(montoDolares > saldoDolares) si quiero convertir mas dolares de los que tengo termino el metodo con return
  asi evito que el saldo quede negarivo.
  .creo una variable llamada pesosRecibidos y guardo cuantos pesos obtengo 
  float pesosRecibidos=montoDolares*tasaConversion; los dolares  que convierto multiplico por el valor de cada dólar
  saldoDolares -=montoDolares; al saldo dolares le resto el montoque converti
  saldo +=pesosRecibidos  al saldo en pesos le sumo los pesos que recibi de la conversion
  .Creo un metodo llamado convertirPesosADolares
  .Recibe dos datos (float montoPesos, float tasaConversion): 
  .MontoPesos:la cantidad de peso que quiere cambiar y 
  .tasaConversion cuanto vale un peso
  .if(monto <= 0) si la cantidad de pesos es menor o igual a cero termino el metodo con return
  .if(tasaConvercion <=0) si la tasa de conversion es menor o igual a cero termino el metodo con  return 
  .if(montoPesos > saldo) si el monto en pesos que quiero convertir es mayor al saldo en pesos termino el metodo con return.
  float dolaresRecibidos=montoPesos/tasaConversion;los pesos que convierto lo divido por el valor de cada pesos
  saldo -=montoPesos; al saldo en pesos le resto el monto que uso para la conversion
  saldoDolares += dolaresRecibidos; al saldo en dolares le sumo los dolares recibidos en la conversion
   
   ##  Clase Test sistema bancario
   .Se encuenta en el paquete test.TestSistemaBancario
   .El metod main es el puento de entrada para ejecutar
   .Creo clientes indivudales y un cliente empresa
   .luego creo una cuenta para cada uno y muestro  sus datos mediante getter
   .uso las cuentas para probar depositos,extraccion y conversiones de monedas
   .Prueba CAJA AHORRO
   .Creo un  Cliente1  y lo asocio a cuenta1.
   .Creo una caja de ahorrocon una tasa del 2,5% mensual
   .hago un intento de deposito  de  un sado negativo  que se rechaza
   .deposito 50000, extraigo 20000 ,por lo que queda  30000.
   .antes de llamar a cobrarInteres(), calculo cuanto interes corresponde sore el saldo de 30000 x 2,5/100=750 
   .despues llamo al metodo y meustro el nuevo saldo.
   .Prueba CUENTA CORRIENTE
    .Creo cliente2 y la asocio a una cuenta2 corriente con 25000 de descubierto autorizado, deposito un cheque de 50000,y deposito 100000 en efectivo. el saldo llega a 150000
    .Luego hago una extraccion de 160000, la operacion me lo permite porque eL SALDO MAS EL DESCUBIERTO DA 175000
    .el nuevo saldo queda  - 10000
    finalmente inteto extraer  30000 , pero como en el descubierto disponible solo me quedan 15000 el metodo no realiza la operacion y el saldo permanece  en 10000
    .Prueba CUENTA CONVERTIBILIDAD
    .Creo un cliente3 de tipo clienteEmpresa y lo asocio a una cuenta convertibilidad
    primero pruebo las operaciones heredadas en pesos
    .deposito en pesos : deposito 130000 en efectivo y deposito un cheque de 80000 =obtengo en saldo $210000
    .despues hago una extraccion  en pesos :de $50000 y me queda en saldo 160.000
    .Deposito en dolares: deposito  1000 dolares extraigo 500 dolares
    para mostrar cuanto se extrajo realmente guardo el saldo anterio y le resto el posterior
    float montoextraido = saldoAntesExtraccion- cuenta3.get.saldoDolares();
    depues convierto 300 dolares a 1500 por cada dolar, y recibo 450.000 pesos 
    .el saldo en pesos  sube a 610.000 pesos
    .el saldo en dolares baja a 200 dolares
    .por ultimo covierto 150.000 pesos a una tasa de $1450 por dolar obtengo 103,45 dolares
    .el saldo en pesos queda en 460.000 pesos 
    .se agregan 103,45 dolares al saldo dolar  , el saldo en dolar queda en 303.45 dolares




  
 

 
 









  




